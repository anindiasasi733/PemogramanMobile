package com.example.projek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
